import argparse
import requests
import json
from http.server import BaseHTTPRequestHandler, HTTPServer
from pythonping import ping


def do_ping_sweep(ip, num_of_host):
    ip_parts = ip.split('.')
    network_ip = ip_parts[0] + '.' + ip_parts[1] + '.' + ip_parts[2] + '.'
    scanned_ip = network_ip + str(int(ip_parts[3]) + num_of_host)
    print(f"[#] Scanning: {scanned_ip}")
    try:
        response = ping(scanned_ip, count=1, timeout=1)
        if response.success():
            print(f"[#] {scanned_ip} is reachable [RTT: {response.rtt_avg_ms} ms]")
        else:
            print(f"[#] {scanned_ip} is unreachable")
    except Exception as e:
        print(f"[!] Error scanning {scanned_ip}: {e}")


def send_http_request(target, method, headers=None, payload=None):
    headers_dict = {}
    if headers:
        for header in headers:
            header_name = header.split(':')[0]
            header_value = header.split(':')[1:]
            headers_dict[header_name] = ':'.join(header_value)

    response = None
    if method == "GET":
        response = requests.get(target, headers=headers_dict)
    elif method == "POST":
        response = requests.post(target, headers=headers_dict, data=payload)

    if response:
        print(
            f"[#] Response status code: {response.status_code}\n"
            f"[#] Response headers: {json.dumps(dict(response.headers), indent=4, sort_keys=True)}\n"
            f"[#] Response content:\n{response.text}"
        )


class SimpleHTTPRequestHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        if self.path == '/sendhttp':
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            request_data = json.loads(post_data)

            target = request_data.get("Target")
            method = request_data.get("Method")
            headers = [f"{request_data.get('Header')}:{request_data.get('Header-value')}"]

            send_http_request(target, method, headers)
            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"HTTP request sent successfully")

    def do_GET(self):
        if self.path == '/scan':
            content_length = int(self.headers['Content-Length'])
            get_data = self.rfile.read(content_length)
            request_data = json.loads(get_data)

            target = request_data.get("target")
            count = int(request_data.get("count"))

            for host_num in range(count):
                do_ping_sweep(target, host_num)

            self.send_response(200)
            self.end_headers()
            self.wfile.write(b"Network scan completed successfully")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='Network scanner and HTTP client')
    parser.add_argument('task', choices=['scan', 'sendhttp', 'server'],
                        help='Task to perform: network scan, send HTTP request, or start server')

    # Параметры для сканирования сети
    parser.add_argument('-i', '--ip', type=str, help='IP address for scanning')
    parser.add_argument('-n', '--num_of_hosts', type=int, help='Number of hosts to scan')

    # Параметры для HTTP-запросов
    parser.add_argument('-t', '--target', type=str, help='Target URL for HTTP request')
    parser.add_argument('-m', '--method', type=str, choices=['GET', 'POST'], help='HTTP method')
    parser.add_argument('-hd', '--headers', nargs='+', help='HTTP headers in format key:value')
    parser.add_argument('-d', '--data', type=str, help='Payload for POST requests')

    args = parser.parse_args()

    if args.task == 'scan':
        for host_num in range(args.num_of_hosts):
            do_ping_sweep(args.ip, host_num)

    elif args.task == 'sendhttp':
        send_http_request(args.target, args.method, args.headers, args.data)

    elif args.task == 'server':  # Новый режим для запуска сервера
        server = HTTPServer(('0.0.0.0', 3000), SimpleHTTPRequestHandler)
        print("Starting server on port 3000...")
        server.serve_forever()
