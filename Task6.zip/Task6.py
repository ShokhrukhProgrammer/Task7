from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import requests
import ipaddress
import socket

def scan_network(target, count, port=80):
    result = []
    try:
        network = ipaddress.ip_network(target, strict=False)
    except ValueError:
        return [{"error": "Invalid network address"}]
    for i, ip in enumerate(network.hosts()):
        if i >= int(count):
            break
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            s.settimeout(0.5)
            try:
                s.connect((str(ip), port))
                result.append({"ip": str(ip), "status": "reachable"})
            except (socket.timeout, ConnectionRefusedError):
                result.append({"ip": str(ip), "status": "unreachable"})
    return result

class RequestHandler(BaseHTTPRequestHandler):

    def _set_response(self, status=200):
        self.send_response(status)
        self.send_header('Content-type', 'application/json')
        self.end_headers()

    def do_POST(self):
        if self.path == '/sendhttp':
            content_length = int(self.headers['Content-Length'])
            post_data = self.rfile.read(content_length)
            try:
                data = json.loads(post_data)
                headers = {data["Header"]: data["Header-value"]}
                response = requests.request(data["Method"], data["Target"], headers=headers)
                self._set_response()
                self.wfile.write(json.dumps({"status": response.status_code, "response": response.text}).encode('utf-8'))
            except Exception as e:
                self._set_response(500)
                self.wfile.write(json.dumps({"error": str(e)}).encode('utf-8'))

    def do_GET(self):
        if self.path == '/scan':
            content_length = int(self.headers['Content-Length'])
            get_data = self.rfile.read(content_length)
            try:
                data = json.loads(get_data)
                target = data["target"]
                count = data["count"]
                result = scan_network(target, count)
                self._set_response()
                self.wfile.write(json.dumps(result).encode('utf-8'))
            except Exception as e:
                self._set_response(500)
                self.wfile.write(json.dumps({"error": str(e)}).encode('utf-8'))

if __name__ == "__main__":
    server_address = ('', 3000)
    httpd = HTTPServer(server_address, RequestHandler)
    print("Server started at http://0.0.0.0:3000")
    httpd.serve_forever()